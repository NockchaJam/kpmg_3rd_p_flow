import pandas as pd
import numpy as np
from sklearn.neighbors import BallTree
from typing import Tuple
from pathlib import Path
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from app.database import SQLALCHEMY_DATABASE_URL

class DataCollector:
    def __init__(self):
        """데이터 수집기 초기화"""
        self.engine = create_engine(SQLALCHEMY_DATABASE_URL)
        self.Session = sessionmaker(bind=self.engine)
        self.vacant_stores = self._load_vacant_stores()
        self.commercial_buildings = self._load_commercial_buildings()
        # 공실 좌표로 BallTree 생성
        self.coords = self.vacant_stores[['latitude', 'longitude']].values
        self.tree = BallTree(np.deg2rad(self.coords), metric='haversine')
        
    def _load_vacant_stores(self) -> pd.DataFrame:
        """DB에서 공실 데이터 로드"""
        try:
            query = text("""
                SELECT latitude, longitude
                FROM vacant_listings
                WHERE latitude IS NOT NULL AND longitude IS NOT NULL
            """)
            with self.engine.connect() as conn:
                df = pd.read_sql(query, conn)
            print(f"로드된 공실 데이터: {len(df)}개")
            print("공실 데이터 샘플:")
            print(df.head())
            return df
        except Exception as e:
            print(f"공실 데이터 로드 실패: {e}")
            raise
            
    def _load_commercial_buildings(self) -> pd.DataFrame:
        """DB에서 상가 데이터 로드"""
        try:
            query = text("""
                SELECT latitude, longitude, industry_category, sales_level
                FROM commercial_buildings
                WHERE latitude IS NOT NULL 
                AND longitude IS NOT NULL 
                AND industry_category IS NOT NULL
                AND sales_level IS NOT NULL
            """)
            with self.engine.connect() as conn:
                df = pd.read_sql(query, conn)
            return df
            
        except Exception as e:
            print(f"상가 데이터 로드 실패: {e}")
            raise
            
    def _haversine_distance(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """두 좌표 간의 거리를 km 단위로 계산"""
        R = 6371.0  # 지구의 반경 (km)
        lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        a = np.sin(dlat/2)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon/2)**2
        c = 2 * np.arcsin(np.sqrt(a))
        return R * c
            
    def _get_nearby_businesses(self, lat: float, lng: float, radius_km: float = 0.5) -> pd.DataFrame:
        """주어진 좌표 주변의 상가 데이터 조회"""
        nearby = self.commercial_buildings.copy()
        nearby['distance'] = nearby.apply(
            lambda row: self._haversine_distance(lat, lng, row['latitude'], row['longitude']),
            axis=1
        )
        return nearby[nearby['distance'] <= radius_km]
        
    def _calculate_business_stats(self, nearby_businesses: pd.DataFrame) -> dict:
        """업종별 통계 계산"""
        stats = {}
        for category in nearby_businesses['industry_category'].unique():
            if pd.isna(category):
                continue
            category_data = nearby_businesses[nearby_businesses['industry_category'] == category]
            if not category_data.empty:
                stats[category] = {
                    'avg_sales_level': round(category_data['sales_level'].astype(float).mean(), 2),
                    'count': len(category_data)
                }
        return stats
        
    def generate_reference_point(self) -> Tuple[float, float]:
        """기존 공실 분포를 반영한 참조 좌표 생성"""
        idx = np.random.randint(0, len(self.vacant_stores))
        base_lat = self.vacant_stores.iloc[idx]['latitude']
        base_lon = self.vacant_stores.iloc[idx]['longitude']
        
        # 현재: 약 50-100m 반경
        lat_offset = np.random.normal(0, 0.0005)
        lon_offset = np.random.normal(0, 0.0005)
        
        # 수정: 약 100-200m 반경으로 증가
        lat_offset = np.random.normal(0, 0.001)
        lon_offset = np.random.normal(0, 0.001)
        
        return (base_lat + lat_offset, base_lon + lon_offset)
        
    def find_nearest_stores(self, point: Tuple[float, float], radius_km: float = 0.5) -> pd.DataFrame:
        """주어진 좌표 근처의 가장 가까운 3개 공실 찾기"""
        radius_rad = radius_km / 6371.0
        point_rad = np.deg2rad(np.array([point]))
        
        indices = self.tree.query_radius(point_rad, r=radius_rad)[0]
        if len(indices) < 3:
            return pd.DataFrame()
            
        distances, indices = self.tree.query(point_rad, k=min(3, len(indices)))
        nearest_stores = self.vacant_stores.iloc[indices[0]]
        
        # 수정: 정확한 좌표 매칭 대신 범위 검색으로 변경
        store_ids = []
        for _, store in nearest_stores.iterrows():
            query = text("""
                SELECT *
                FROM vacant_listings
                WHERE ABS(latitude - :lat) < 0.00001 
                AND ABS(longitude - :lng) < 0.00001
                LIMIT 1
            """)
            with self.engine.connect() as conn:
                result = conn.execute(query, {
                    'lat': float(store['latitude']), 
                    'lng': float(store['longitude'])
                }).first()
                if result:
                    # 수정: Row 객체를 dictionary로 올바르게 변환
                    store_dict = {key: value for key, value in result._mapping.items()}
                    store_ids.append(store_dict)
                    
        return pd.DataFrame(store_ids)
        
    def collect_data(self, n_samples: int = 1000) -> pd.DataFrame:
        """데이터 수집 실행"""
        results = []
        attempts = 0
        max_attempts = n_samples * 5
        group_id = 1
        
        while len(results) < n_samples * 3 and attempts < max_attempts:  # 3개씩 저장하므로 목표를 3배로
            attempts += 1
            
            # 참조 좌표 생성
            point = self.generate_reference_point()
            nearest_stores = self.find_nearest_stores(point)
            
            if len(nearest_stores) < 3:
                continue
                
            # 주변 상가 데이터 수집
            nearby_businesses = self._get_nearby_businesses(point[0], point[1])
            if len(nearby_businesses) == 0:
                continue
                
            business_stats = self._calculate_business_stats(nearby_businesses)
            if not business_stats:
                continue
                
            # 업종별 통계 계산
            business_stats_dict = {}
            for category, stats in business_stats.items():
                business_stats_dict[f'{category}_avg_sales_level'] = stats['avg_sales_level']
                business_stats_dict[f'{category}_count'] = stats['count']
            
            # 각 공실을 개별 행으로 저장
            for i, (_, store) in enumerate(nearest_stores.iterrows(), 1):
                store_data = {
                    'group_id': group_id,
                    'store_rank': i,  # 해당 그룹 내 순위
                    'reference_lat': point[0],
                    'reference_lon': point[1],
                    'store_lat': store['latitude'],
                    'store_lon': store['longitude'],
                    'distance': self._haversine_distance(
                        point[0], point[1], 
                        store['latitude'], 
                        store['longitude']
                    ) * 1000  # km to meters
                }
                
                # 주변 시설 정보 추가
                for col in store.index:
                    if col not in ['latitude', 'longitude'] and not pd.isna(store[col]):
                        store_data[col] = store[col]
                
                # 업종별 통계 추가
                store_data.update(business_stats_dict)
                
                results.append(store_data)
            
            group_id += 1
            
            if len(results) % 300 == 0:  # 100개 그룹마다 출력
                print(f"수집 진행률: {len(results)//3}/{n_samples} 그룹 "
                      f"({(len(results)/3/n_samples*100):.1f}%)")
        
        if len(results) < n_samples * 3:
            print(f"경고: 요청된 {n_samples} 그룹 중 {len(results)//3}개 그룹만 수집되었습니다")
            
        return pd.DataFrame(results)

def main():
    """메인 실행 함수"""
    try:
        collector = DataCollector()
        result_df = collector.collect_data(n_samples=1000)
        
        output_dir = Path('data/output')
        output_dir.mkdir(exist_ok=True, parents=True)
        output_path = output_dir / 'collected_samples.csv'
        result_df.to_csv(output_path, index=False)
        print(f"데이터 수집 완료! 결과가 {output_path}에 저장되었습니다.")
        
    except Exception as e:
        print(f"데이터 수집 중 오류 발생: {e}")

if __name__ == "__main__":
    main() 